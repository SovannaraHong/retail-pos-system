-- MySQL dump 10.13  Distrib 8.4.11, for Linux (x86_64)
--
-- Host: localhost    Database: retail_pos
-- ------------------------------------------------------
-- Server version	8.4.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `brands`
--

DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `brands` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `brands_name_index` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brands`
--

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
INSERT INTO `brands` VALUES (1,'Samsung Electronics',58,'2013-07-18 05:09:31','2026-10-28 14:24:40',NULL),(2,'Ishikawa Seiko',124,'2003-06-14 13:02:07','2026-10-28 14:25:59',NULL),(3,'Samsung',1,'2026-10-28 14:24:11','2026-10-28 14:24:11',NULL);
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `categories_parent_id_foreign` (`parent_id`),
  KEY `categories_name_index` (`name`),
  CONSTRAINT `categories_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,NULL,'Iced Coffee','Coffee products and drinks',1,'2026-10-28 07:57:02','2026-10-28 07:58:24',NULL),(2,1,'Hot Coffee','Hot coffee drinks',1,'2026-10-28 07:57:48','2026-10-28 08:01:02',NULL);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `points` int unsigned NOT NULL DEFAULT '0',
  `note` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customers_name_index` (`name`),
  KEY `customers_phone_index` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'John Smith','012999888','johnsmith@example.com','Siem Reap, Cambodia',164,'VIP customer',1,'2019-04-01 18:22:07','2026-11-02 14:04:26',NULL),(2,'John Doe','012345673','john@example.com','Phnom Penh, Cambodia',0,'Regular customer',1,'2026-11-02 14:03:41','2026-11-02 14:05:35',NULL);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses`
--

DROP TABLE IF EXISTS `expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expenses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `expense_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `expenses_user_id_foreign` (`user_id`),
  KEY `expenses_expense_date_index` (`expense_date`),
  KEY `expenses_category_index` (`category`),
  CONSTRAINT `expenses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses`
--

LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
INSERT INTO `expenses` VALUES (2,1,'electricity',50.00,'Electricity bill for November','2026-11-02','2026-11-02 14:15:17','2026-11-02 14:15:40',NULL);
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`),
  KEY `failed_jobs_connection_queue_failed_at_index` (`connection`,`queue`,`failed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` smallint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `khqr_payments`
--

DROP TABLE IF EXISTS `khqr_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `khqr_payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `sale_id` bigint unsigned DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `amount` decimal(12,2) NOT NULL,
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qr` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `md5` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cart` json NOT NULL,
  `expires_at` timestamp NOT NULL,
  `paid_at` timestamp NULL DEFAULT NULL,
  `last_checked_at` timestamp NULL DEFAULT NULL,
  `bakong_hash` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_account` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bakong_response` json DEFAULT NULL,
  `error` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `khqr_payments_reference_unique` (`reference`),
  UNIQUE KEY `khqr_payments_md5_unique` (`md5`),
  UNIQUE KEY `khqr_payments_bakong_hash_unique` (`bakong_hash`),
  KEY `khqr_payments_user_id_foreign` (`user_id`),
  KEY `khqr_payments_sale_id_foreign` (`sale_id`),
  KEY `khqr_payments_status_expires_at_index` (`status`,`expires_at`),
  CONSTRAINT `khqr_payments_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE SET NULL,
  CONSTRAINT `khqr_payments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `khqr_payments`
--

LOCK TABLES `khqr_payments` WRITE;
/*!40000 ALTER TABLE `khqr_payments` DISABLE KEYS */;
INSERT INTO `khqr_payments` VALUES (1,'KQT1ZQ1NW2',1,NULL,'pending',25.91,'USD','00020101021229220018hongsovannara@bkrt520459995303840540525.915802KH5917Retail POS System6010Phnom Penh62140110KQT1ZQ1NW29934001317934220697890113179342236978963047577','43134f4a7bbb86715d638ed6ccdeec3f','{\"tax\": 22.91, \"note\": \"Customer KHQR payment\", \"lines\": [{\"qty\": 2, \"sku\": \"DRINK-COKE-330\", \"tax\": 0.4, \"discount\": 0, \"cost_price\": 2, \"line_total\": 4.4, \"product_id\": 1, \"unit_price\": 2, \"product_name\": \"Coca-Cola 330ml Updated\"}, {\"qty\": 3, \"sku\": \"EE-DE-0463-X\", \"tax\": 22.51, \"discount\": 2, \"cost_price\": 2, \"line_total\": 26.51, \"product_id\": 2, \"unit_price\": 2, \"product_name\": \"Chris Rodriguez\"}], \"total\": 25.91, \"discount\": 7, \"subtotal\": 10, \"customer_id\": 1}','2026-10-31 04:52:49',NULL,NULL,NULL,NULL,NULL,NULL,'2026-10-31 04:47:49','2026-10-31 04:47:49'),(2,'KQO7IUSUQS',1,NULL,'pending',25.91,'USD','00020101021229220018hongsovannara@bkrt520459995303840540525.915802KH5917Retail POS System6010Phnom Penh62140110KQO7IUSUQS993400131793422371362011317934226713626304BB10','2df80286d7afed316e638158637d846b','{\"tax\": 22.91, \"note\": \"Customer KHQR payment\", \"lines\": [{\"qty\": 2, \"sku\": \"DRINK-COKE-330\", \"tax\": 0.4, \"discount\": 0, \"cost_price\": 2, \"line_total\": 4.4, \"product_id\": 1, \"unit_price\": 2, \"product_name\": \"Coca-Cola 330ml Updated\"}, {\"qty\": 3, \"sku\": \"EE-DE-0463-X\", \"tax\": 22.51, \"discount\": 2, \"cost_price\": 2, \"line_total\": 26.51, \"product_id\": 2, \"unit_price\": 2, \"product_name\": \"Chris Rodriguez\"}], \"total\": 25.91, \"discount\": 7, \"subtotal\": 10, \"customer_id\": 1}','2026-10-31 04:57:51',NULL,NULL,NULL,NULL,NULL,NULL,'2026-10-31 04:52:51','2026-10-31 04:52:51'),(3,'KQMXFLRTGM',1,NULL,'pending',0.03,'USD','00020101021229220018hongsovannara@bkrt52045999530384054040.035802KH5917Retail POS System6010Phnom Penh62140110KQMXFLRTGM9934001317934226037200113179342290372063043C02','27699d524cb35911179c8c6a35bf709f','{\"tax\": 0, \"note\": \"Customer KHQR payment\", \"lines\": [{\"qty\": 2, \"sku\": \"EE-DE-0463-X\", \"tax\": 0, \"discount\": 0, \"cost_price\": 2, \"line_total\": 0.02, \"product_id\": 2, \"unit_price\": 0.01, \"product_name\": \"Chris Rodriguez\"}, {\"qty\": 1, \"sku\": \"ED-AC-6018-N\", \"tax\": 0, \"discount\": 0, \"cost_price\": 2, \"line_total\": 0.01, \"product_id\": 3, \"unit_price\": 0.01, \"product_name\": \"Yau Yu Ling\"}], \"total\": 0.03, \"discount\": 0, \"subtotal\": 0.03, \"customer_id\": 1}','2026-10-31 05:01:43',NULL,NULL,NULL,NULL,NULL,NULL,'2026-10-31 04:56:43','2026-10-31 04:56:43'),(4,'KQB8AIEYOO',1,NULL,'pending',0.03,'USD','00020101021229220018hongsovannara@bkrt52045999530384054040.035802KH5917Retail POS System6010Phnom Penh62140110KQB8AIEYOO993400131793449102335011317934494023356304A915','d5b34aaea7eb1686d1628faf03aa8498','{\"tax\": 0, \"note\": \"Customer KHQR payment\", \"lines\": [{\"qty\": 2, \"sku\": \"EE-DE-0463-X\", \"tax\": 0, \"discount\": 0, \"cost_price\": 2, \"line_total\": 0.02, \"product_id\": 2, \"unit_price\": 0.01, \"product_name\": \"Chris Rodriguez\"}, {\"qty\": 1, \"sku\": \"ED-AC-6018-N\", \"tax\": 0, \"discount\": 0, \"cost_price\": 2, \"line_total\": 0.01, \"product_id\": 3, \"unit_price\": 0.01, \"product_name\": \"Yau Yu Ling\"}], \"total\": 0.03, \"discount\": 0, \"subtotal\": 0.03, \"customer_id\": 1}','2026-10-31 12:23:22',NULL,NULL,NULL,NULL,NULL,NULL,'2026-10-31 12:18:22','2026-10-31 12:18:22'),(5,'KQUAE3WD0W',1,6,'paid',0.03,'USD','00020101021229220018hongsovannara@bkrt52045999530384054040.035802KH5917Retail POS System6010Phnom Penh62140110KQUAE3WD0W993400131793451954551011317934522545516304B95D','f6a2adaae385167ba3d9299484efa4f9','{\"tax\": 0, \"note\": \"Customer KHQR payment\", \"lines\": [{\"qty\": 2, \"sku\": \"EE-DE-0463-X\", \"tax\": 0, \"discount\": 0, \"cost_price\": 2, \"line_total\": 0.02, \"product_id\": 2, \"unit_price\": 0.01, \"product_name\": \"Chris Rodriguez\"}, {\"qty\": 1, \"sku\": \"ED-AC-6018-N\", \"tax\": 0, \"discount\": 0, \"cost_price\": 2, \"line_total\": 0.01, \"product_id\": 3, \"unit_price\": 0.01, \"product_name\": \"Yau Yu Ling\"}], \"total\": 0.03, \"discount\": 0, \"subtotal\": 0.03, \"customer_id\": 1}','2026-10-31 13:10:54','2026-10-31 13:08:56','2026-10-31 13:08:56','7b623445ac1f326867eb42ef31721c33f92b412fe6a6fcb4a25f525af5c17cb4','abaakhppxxx@abaa','{\"hash\": \"7b623445ac1f326867eb42ef31721c33f92b412fe6a6fcb4a25f525af5c17cb4\", \"amount\": 0.03, \"currency\": \"USD\", \"description\": null, \"externalRef\": \"100FT40221853019\", \"toAccountId\": \"hongsovannara@bkrt\", \"receiverBank\": null, \"createdDateMs\": 1793451999000, \"fromAccountId\": \"abaakhppxxx@abaa\", \"instructionRef\": null, \"trackingStatus\": null, \"acknowledgedDateMs\": 1793452001000, \"receiverBankAccount\": null}',NULL,'2026-10-31 13:05:54','2026-10-31 13:08:56'),(6,'KQOFZXC9OV',1,NULL,'pending',0.03,'USD','00020101021229220018hongsovannara@bkrt52045999530384054040.035802KH5917Retail POS System6010Phnom Penh62140110KQOFZXC9OV9934001317935203380640113179352063806463046946','9bbf4e32328de25166d0e1a3f63b2a48','{\"tax\": 0, \"note\": \"Customer KHQR payment\", \"lines\": [{\"qty\": 2, \"sku\": \"EE-DE-0463-X\", \"tax\": 0, \"discount\": 0, \"cost_price\": 2, \"line_total\": 0.02, \"product_id\": 2, \"unit_price\": 0.01, \"product_name\": \"Chris Rodriguez\"}, {\"qty\": 1, \"sku\": \"ED-AC-6018-N\", \"tax\": 0, \"discount\": 0, \"cost_price\": 2, \"line_total\": 0.01, \"product_id\": 3, \"unit_price\": 0.01, \"product_name\": \"Yau Yu Ling\"}], \"total\": 0.03, \"discount\": 0, \"subtotal\": 0.03, \"customer_id\": 1}','2026-11-01 08:10:38',NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-01 08:05:38','2026-11-01 08:05:38'),(7,'KQW7KS99IU',1,NULL,'pending',0.03,'USD','00020101021229220018hongsovannara@bkrt52045999530384054040.035802KH5917Retail POS System6010Phnom Penh62140110KQW7KS99IU993400131793522461473011317935227614736304E4E6','30586ea333fc07a3ad85c53e8676232e','{\"tax\": 0, \"note\": \"Customer KHQR payment\", \"lines\": [{\"qty\": 2, \"sku\": \"EE-DE-0463-X\", \"tax\": 0, \"discount\": 0, \"cost_price\": 2, \"line_total\": 0.02, \"product_id\": 2, \"unit_price\": 0.01, \"product_name\": \"Chris Rodriguez\"}, {\"qty\": 1, \"sku\": \"ED-AC-6018-N\", \"tax\": 0, \"discount\": 0, \"cost_price\": 2, \"line_total\": 0.01, \"product_id\": 3, \"unit_price\": 0.01, \"product_name\": \"Yau Yu Ling\"}], \"total\": 0.03, \"discount\": 0, \"subtotal\": 0.03, \"customer_id\": 1}','2026-11-01 08:46:01',NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-01 08:41:01','2026-11-01 08:41:01'),(8,'KQWQFX0K3F',1,NULL,'pending',0.03,'USD','00020101021229220018hongsovannara@bkrt52045999530384054040.035802KH5917Retail POS System6010Phnom Penh62140110KQWQFX0K3F9934001317935238453800113179352414538063047A13','61be67c7d21174b9766753eb92b686c6','{\"tax\": 0, \"note\": \"Customer KHQR payment\", \"lines\": [{\"qty\": 2, \"sku\": \"EE-DE-0463-X\", \"tax\": 0, \"discount\": 0, \"cost_price\": 2, \"line_total\": 0.02, \"product_id\": 2, \"unit_price\": 0.01, \"product_name\": \"Chris Rodriguez\"}, {\"qty\": 1, \"sku\": \"ED-AC-6018-N\", \"tax\": 0, \"discount\": 0, \"cost_price\": 2, \"line_total\": 0.01, \"product_id\": 3, \"unit_price\": 0.01, \"product_name\": \"Yau Yu Ling\"}], \"total\": 0.03, \"discount\": 0, \"subtotal\": 0.03, \"customer_id\": null}','2026-11-01 09:09:05',NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-01 09:04:05','2026-11-01 09:04:05');
/*!40000 ALTER TABLE `khqr_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2026_10_25_143716_create_permission_tables',1),(5,'2026_10_26_132908_add_image_to_users_table',1),(6,'2026_10_27_141347_create_categories_table',1),(7,'2026_10_27_141426_create_brands_table',1),(8,'2026_10_27_141445_create_suppliers_table',1),(9,'2026_10_27_141519_create_products_table',1),(10,'2026_10_27_141542_create_customers_table',1),(11,'2026_10_27_141557_create_purchases_table',1),(12,'2026_10_27_141613_create_purchases_items_table',1),(13,'2026_10_27_141631_create_shifts_table',1),(14,'2026_10_27_141645_create_sales_table',1),(15,'2026_10_27_141707_create_payments_table',1),(16,'2026_10_27_141815_create_stock_movements_table',1),(17,'2026_10_27_141905_create_sale_items_table',1),(18,'2026_10_27_141926_create_sale_returns_table',1),(19,'2026_10_27_141937_create_sale_return_items_table',1),(20,'2026_10_27_141956_create_expenses_table',1),(21,'2026_10_27_142012_create_settings_table',1),(22,'2026_10_30_141242_create_khqr_payments_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\Models\\User',1),(1,'App\\Models\\User',2),(1,'App\\Models\\User',4),(1,'App\\Models\\User',5);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `sale_id` bigint unsigned NOT NULL,
  `method` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `reference` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payments_sale_id_foreign` (`sale_id`),
  KEY `payments_method_index` (`method`),
  CONSTRAINT `payments_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (1,4,'cash',5.91,NULL,'2026-10-30 13:46:22','2026-10-30 13:46:22','2026-10-30 13:46:22'),(2,4,'qr',20.00,'BAKONG-REF-20261030','2026-10-30 13:46:22','2026-10-30 13:46:22','2026-10-30 13:46:22'),(3,5,'cash',5.91,NULL,'2026-10-31 04:54:57','2026-10-31 04:54:57','2026-10-31 04:54:57'),(4,5,'card',20.00,'CARD-REF-001','2026-10-31 04:54:57','2026-10-31 04:54:57','2026-10-31 04:54:57'),(5,6,'qr',0.03,'7b623445ac1f326867eb42ef31721c33f92b412fe6a6fcb4a25f525af5c17cb4','2026-10-31 13:08:56','2026-10-31 13:08:56','2026-10-31 13:08:56');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'users.view','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(2,'users.create','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(3,'users.update','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(4,'users.delete','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(5,'roles.view','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(6,'roles.create','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(7,'roles.update','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(8,'roles.delete','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(9,'permissions.view','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(10,'permissions.create','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(11,'permissions.update','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(12,'permissions.delete','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(13,'categories.view','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(14,'categories.create','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(15,'categories.update','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(16,'categories.delete','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(17,'brands.view','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(18,'brands.create','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(19,'brands.update','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(20,'brands.delete','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(21,'suppliers.view','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(22,'suppliers.create','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(23,'suppliers.update','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(24,'suppliers.delete','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(25,'products.view','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(26,'products.create','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(27,'products.update','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(28,'products.delete','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(29,'customers.view','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(30,'customers.create','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(31,'customers.update','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(32,'customers.delete','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(33,'purchases.view','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(34,'purchases.create','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(35,'purchases.update','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(36,'stock.view','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(37,'stock.adjust','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(38,'sales.create','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(39,'sales.view','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(40,'sales.refund','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(41,'shifts.open','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(42,'shifts.close','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(43,'shifts.view','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(44,'expenses.view','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(45,'expenses.create','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(46,'expenses.delete','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(47,'reports.view','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(48,'settings.view','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(49,'settings.update','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(50,'manage-roles','api','2026-10-28 07:44:48','2026-10-28 07:44:48'),(51,'manage-users','api','2026-10-28 07:44:48','2026-10-28 07:44:48'),(52,'sales.discount','api','2026-10-30 13:29:35','2026-10-30 13:29:35'),(53,'sales.void','api','2026-10-30 13:53:21','2026-10-30 13:53:21');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint unsigned DEFAULT NULL,
  `brand_id` bigint unsigned DEFAULT NULL,
  `supplier_id` bigint unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sku` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `barcode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pcs',
  `cost_price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `sell_price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `tax_rate` decimal(5,2) NOT NULL DEFAULT '0.00',
  `track_stock` tinyint(1) NOT NULL DEFAULT '1',
  `stock_qty` decimal(12,3) NOT NULL DEFAULT '0.000',
  `reorder_level` decimal(12,3) NOT NULL DEFAULT '0.000',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_sku_unique` (`sku`),
  UNIQUE KEY `products_barcode_unique` (`barcode`),
  KEY `products_category_id_foreign` (`category_id`),
  KEY `products_brand_id_foreign` (`brand_id`),
  KEY `products_supplier_id_foreign` (`supplier_id`),
  KEY `products_name_index` (`name`),
  CONSTRAINT `products_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE SET NULL,
  CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `products_supplier_id_foreign` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,1,1,1,'Coca-Cola 330ml Updated','DRINK-COKE-330','1234567890123','Updated Coca-Cola description','products/teVPJ9f8gmILPkLmZYsM96jc9HSRS2MxkgzY3L4N.jpg','can',2.00,2.00,10.00,1,70.000,15.000,1,'2026-10-28 12:28:06','2026-10-31 04:54:57',NULL),(2,1,3,2,'Chris Rodriguez','EE-DE-0463-X','9780520228948','Such sessions are also susceptible to session hijacking, where a malicious user takes over your session once you have authenticated. Export Wizard allows you to export data from tables, collections, views, or query results to any available formats. The reason why a great man is great is that he resolves to be a great man. HTTP Tunneling is a method for connecting to a server that uses the same protocol (http://) and the same port (port 80) as a web server does. Creativity is intelligence having fun. Navicat provides a wide range advanced features, such as compelling code editing capabilities, smart code-completion, SQL formatting, and more. All the Navicat Cloud objects are located under different projects. You can share the project to other Navicat Cloud accounts for collaboration. It is used while your ISPs do not allow direct connections, but allows establishing HTTP connections. Navicat is a multi-connections Database Administration tool allowing you to connect to MySQL, Oracle, PostgreSQL, SQLite, SQL Server, MariaDB and/or MongoDB databases, making database administration to multiple kinds of database so easy. Instead of wondering when your next vacation is, maybe you should set up a life you don’t need to escape from. Navicat is a multi-connections Database Administration tool allowing you to connect to MySQL, Oracle, PostgreSQL, SQLite, SQL Server, MariaDB and/or MongoDB databases, making database administration to multiple kinds of database so easy. The Main Window consists of several toolbars and panes for you to work on connections, database objects and advanced tools. You will succeed because most people are lazy. How we spend our days is, of course, how we spend our lives. Navicat Data Modeler is a powerful and cost-effective database design tool which helps you build high-quality conceptual, logical and physical data models. It wasn’t raining when Noah built the ark. To get a secure connection, the first thing you need to do is to install OpenSSL Library and download Database Source. Creativity is intelligence having fun. Navicat provides a wide range advanced features, such as compelling code editing capabilities, smart code-completion, SQL formatting, and more. Actually it is just in an idea when feel oneself can achieve and cannot achieve. The Synchronize to Database function will give you a full picture of all database differences. Navicat provides a wide range advanced features, such as compelling code editing capabilities, smart code-completion, SQL formatting, and more. Difficult circumstances serve as a textbook of life for people. Genius is an infinite capacity for taking pains. If it scares you, it might be a good thing to try. HTTP Tunneling is a method for connecting to a server that uses the same protocol (http://) and the same port (port 80) as a web server does. Success consists of going from failure to failure without loss of enthusiasm. Optimism is the one quality more associated with success and happiness than any other. Anyone who has ever made anything of importance was disciplined. Remember that failure is an event, not a person. What you get by achieving your goals is not as important as what you become by achieving your goals. To get a secure connection, the first thing you need to do is to install OpenSSL Library and download Database Source. If the plan doesn’t work, change the plan, but never the goal. Navicat Monitor is a safe, simple and agentless remote server monitoring tool that is packed with powerful features to make your monitoring effective as possible. After comparing data, the window shows the number of records that will be inserted, updated or deleted in the target. You will succeed because most people are lazy. Sometimes you win, sometimes you learn. What you get by achieving your goals is not as important as what you become by achieving your goals. Such sessions are also susceptible to session hijacking, where a malicious user takes over your session once you have authenticated. Always keep your eyes open. Keep watching. Because whatever you see can inspire you. You will succeed because most people are lazy. I will greet this day with love in my heart. The first step is as good as half over. The On Startup feature allows you to control what tabs appear when you launch Navicat. Optimism is the one quality more associated with success and happiness than any other. Remember that failure is an event, not a person. A man’s best friends are his ten fingers. The past has no power over the present moment. The repository database can be an existing MySQL, MariaDB, PostgreSQL, SQL Server, or Amazon RDS instance. Navicat Monitor requires a repository to store alerts and metrics for historical analysis. The Information Pane shows the detailed object information, project activities, the DDL of database objects, object dependencies, membership of users/roles and preview. Anyone who has ever made anything of importance was disciplined. The reason why a great man is great is that he resolves to be a great man. A man is not old until regrets take the place of dreams. Anyone who has ever made anything of importance was disciplined. To successfully establish a new connection to local/remote server - no matter via SSL, SSH or HTTP, set the database login information in the General tab. All the Navicat Cloud objects are located under different projects. You can share the project to other Navicat Cloud accounts for collaboration. To open a query using an external editor, control-click it and select Open with External Editor. You can set the file path of an external editor in Preferences. After comparing data, the window shows the number of records that will be inserted, updated or deleted in the target. It wasn’t raining when Noah built the ark. Navicat is a multi-connections Database Administration tool allowing you to connect to MySQL, Oracle, PostgreSQL, SQLite, SQL Server, MariaDB and/or MongoDB databases, making database administration to multiple kinds of database so easy. Navicat Data Modeler enables you to build high-quality conceptual, logical and physical data models for a wide variety of audiences. Optimism is the one quality more associated with success and happiness than any other. Optimism is the one quality more associated with success and happiness than any other. Navicat Monitor is a safe, simple and agentless remote server monitoring tool that is packed with powerful features to make your monitoring effective as possible. SSH serves to prevent such vulnerabilities and allows you to access a remote server\'s shell without compromising security. Navicat Monitor can be installed on any local computer or virtual machine and does not require any software installation on the servers being monitored. You must be the change you wish to see in the world. SSH serves to prevent such vulnerabilities and allows you to access a remote server\'s shell without compromising security. A query is used to extract data from the database in a readable format according to the user\'s request. It collects process metrics such as CPU load, RAM usage, and a variety of other resources over SSH/SNMP. The Information Pane shows the detailed object information, project activities, the DDL of database objects, object dependencies, membership of users/roles and preview. Secure Sockets Layer(SSL) is a protocol for transmitting private documents via the Internet. It collects process metrics such as CPU load, RAM usage, and a variety of other resources over SSH/SNMP. I may not have gone where I intended to go, but I think I have ended up where I needed to be.','j9JMC6xFeH','QUuNznmA1C',2.00,0.01,0.00,1,88.100,378.512,1,'2021-06-26 09:27:08','2026-10-31 13:08:56',NULL),(3,2,3,3,'Yau Yu Ling','ED-AC-6018-N','7134656939698','There is no way to happiness. Happiness is the way. If you wait, all that happens is you get older. A comfort zone is a beautiful place, but nothing ever grows there. Navicat Monitor can be installed on any local computer or virtual machine and does not require any software installation on the servers being monitored. Typically, it is employed as an encrypted version of Telnet. After comparing data, the window shows the number of records that will be inserted, updated or deleted in the target.','AhgQVfAzpC','ZUSRoeGWHg',2.00,0.01,0.00,1,679.348,741.927,1,'2019-03-13 10:51:10','2026-10-31 13:08:56',NULL);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchases`
--

DROP TABLE IF EXISTS `purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchases` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'received',
  `subtotal` decimal(12,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `tax` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total` decimal(12,2) NOT NULL DEFAULT '0.00',
  `paid_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `note` text COLLATE utf8mb4_unicode_ci,
  `purchased_at` date NOT NULL,
  `received_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `purchases_reference_no_unique` (`reference_no`),
  KEY `purchases_supplier_id_foreign` (`supplier_id`),
  KEY `purchases_user_id_foreign` (`user_id`),
  KEY `purchases_status_index` (`status`),
  KEY `purchases_purchased_at_index` (`purchased_at`),
  CONSTRAINT `purchases_supplier_id_foreign` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `purchases_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchases`
--

LOCK TABLES `purchases` WRITE;
/*!40000 ALTER TABLE `purchases` DISABLE KEYS */;
INSERT INTO `purchases` VALUES (1,'PO-TEST-0004',1,1,'received',5.00,0.00,0.00,5.00,0.00,'Restock Coca-Cola','2026-10-29','2026-10-29 14:20:24','2026-10-29 14:20:24','2026-10-29 14:20:24'),(2,'PO-TEST-0006',1,1,'received',5.00,0.00,0.00,5.00,0.00,'Restock Coca-Cola','2026-10-29','2026-10-29 14:23:10','2026-10-29 14:23:10','2026-10-29 14:23:10'),(3,'PO-TEST-0007',1,1,'received',5.00,0.00,0.00,5.00,0.00,'Restock Coca-Cola','2026-10-29','2026-10-29 14:32:11','2026-10-29 14:31:50','2026-10-29 14:32:11'),(4,'PO-TEST-0008',1,1,'cancelled',5.00,0.00,0.00,5.00,0.00,'Restock Coca-Cola','2026-10-29',NULL,'2026-10-29 14:33:24','2026-10-29 14:33:31');
/*!40000 ALTER TABLE `purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchases_items`
--

DROP TABLE IF EXISTS `purchases_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchases_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `purchase_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `qty` decimal(12,3) NOT NULL,
  `unit_cost` decimal(12,2) NOT NULL,
  `line_total` decimal(12,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchases_items_purchase_id_foreign` (`purchase_id`),
  KEY `purchases_items_product_id_foreign` (`product_id`),
  CONSTRAINT `purchases_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `purchases_items_purchase_id_foreign` FOREIGN KEY (`purchase_id`) REFERENCES `purchases` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchases_items`
--

LOCK TABLES `purchases_items` WRITE;
/*!40000 ALTER TABLE `purchases_items` DISABLE KEYS */;
INSERT INTO `purchases_items` VALUES (1,1,1,10.000,0.50,5.00,'2026-10-29 14:20:24','2026-10-29 14:20:24'),(2,2,1,10.000,0.50,5.00,'2026-10-29 14:23:10','2026-10-29 14:23:10'),(3,3,1,10.000,0.50,5.00,'2026-10-29 14:31:50','2026-10-29 14:31:50'),(4,4,1,10.000,0.50,5.00,'2026-10-29 14:33:24','2026-10-29 14:33:24');
/*!40000 ALTER TABLE `purchases_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1),(8,1),(9,1),(10,1),(11,1),(12,1),(13,1),(14,1),(15,1),(16,1),(17,1),(18,1),(19,1),(20,1),(21,1),(22,1),(23,1),(24,1),(25,1),(26,1),(27,1),(28,1),(29,1),(30,1),(31,1),(32,1),(33,1),(34,1),(35,1),(36,1),(37,1),(38,1),(39,1),(40,1),(41,1),(42,1),(43,1),(44,1),(45,1),(46,1),(47,1),(48,1),(49,1),(52,1),(53,1),(13,2),(14,2),(15,2),(17,2),(18,2),(19,2),(21,2),(22,2),(23,2),(25,2),(26,2),(27,2),(29,2),(30,2),(31,2),(33,2),(34,2),(35,2),(36,2),(37,2),(38,2),(39,2),(40,2),(43,2),(44,2),(45,2),(47,2),(13,3),(17,3),(25,3),(29,3),(30,3),(38,3),(39,3),(41,3),(42,3);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'admin','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(2,'manager','api','2026-10-28 07:40:44','2026-10-28 07:40:44'),(3,'cashier','api','2026-10-28 07:40:44','2026-10-28 07:40:44');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sale_items`
--

DROP TABLE IF EXISTS `sale_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sale_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `sale_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sku` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qty` decimal(12,3) NOT NULL,
  `unit_price` decimal(12,2) NOT NULL,
  `cost_price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `tax` decimal(12,2) NOT NULL DEFAULT '0.00',
  `line_total` decimal(12,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sale_items_sale_id_foreign` (`sale_id`),
  KEY `sale_items_product_id_foreign` (`product_id`),
  CONSTRAINT `sale_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `sale_items_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_items`
--

LOCK TABLES `sale_items` WRITE;
/*!40000 ALTER TABLE `sale_items` DISABLE KEYS */;
INSERT INTO `sale_items` VALUES (3,4,1,'Coca-Cola 330ml Updated','DRINK-COKE-330',2.000,2.00,2.00,0.00,0.40,4.40,'2026-10-30 13:46:22','2026-10-30 13:46:22'),(4,4,2,'Chris Rodriguez','EE-DE-0463-X',3.000,2.00,2.00,2.00,22.51,26.51,'2026-10-30 13:46:22','2026-10-30 13:46:22'),(5,5,1,'Coca-Cola 330ml Updated','DRINK-COKE-330',2.000,2.00,2.00,0.00,0.40,4.40,'2026-10-31 04:54:57','2026-10-31 04:54:57'),(6,5,2,'Chris Rodriguez','EE-DE-0463-X',3.000,2.00,2.00,2.00,22.51,26.51,'2026-10-31 04:54:57','2026-10-31 04:54:57'),(7,6,2,'Chris Rodriguez','EE-DE-0463-X',2.000,0.01,2.00,0.00,0.00,0.02,'2026-10-31 13:08:56','2026-10-31 13:08:56'),(8,6,3,'Yau Yu Ling','ED-AC-6018-N',1.000,0.01,2.00,0.00,0.00,0.01,'2026-10-31 13:08:56','2026-10-31 13:08:56');
/*!40000 ALTER TABLE `sale_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sale_return_items`
--

DROP TABLE IF EXISTS `sale_return_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sale_return_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `sale_return_id` bigint unsigned NOT NULL,
  `sale_item_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `qty` decimal(12,3) NOT NULL,
  `unit_price` decimal(12,2) NOT NULL,
  `line_total` decimal(12,2) NOT NULL,
  `restock` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sale_return_items_sale_return_id_foreign` (`sale_return_id`),
  KEY `sale_return_items_sale_item_id_foreign` (`sale_item_id`),
  KEY `sale_return_items_product_id_foreign` (`product_id`),
  CONSTRAINT `sale_return_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `sale_return_items_sale_item_id_foreign` FOREIGN KEY (`sale_item_id`) REFERENCES `sale_items` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `sale_return_items_sale_return_id_foreign` FOREIGN KEY (`sale_return_id`) REFERENCES `sale_returns` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_return_items`
--

LOCK TABLES `sale_return_items` WRITE;
/*!40000 ALTER TABLE `sale_return_items` DISABLE KEYS */;
INSERT INTO `sale_return_items` VALUES (1,2,5,1,1.000,2.00,1.85,0,'2026-11-01 13:39:24','2026-11-01 13:39:24');
/*!40000 ALTER TABLE `sale_return_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sale_returns`
--

DROP TABLE IF EXISTS `sale_returns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sale_returns` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `return_no` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sale_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `total_refund` decimal(12,2) NOT NULL DEFAULT '0.00',
  `refund_method` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'cash',
  `reason` text COLLATE utf8mb4_unicode_ci,
  `returned_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sale_returns_return_no_unique` (`return_no`),
  KEY `sale_returns_sale_id_foreign` (`sale_id`),
  KEY `sale_returns_user_id_foreign` (`user_id`),
  CONSTRAINT `sale_returns_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `sale_returns_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_returns`
--

LOCK TABLES `sale_returns` WRITE;
/*!40000 ALTER TABLE `sale_returns` DISABLE KEYS */;
INSERT INTO `sale_returns` VALUES (2,'RET-20261101-000002',5,1,1.85,'cash','Customer returned damaged product','2026-11-01 13:39:24','2026-11-01 13:39:24','2026-11-01 13:39:24');
/*!40000 ALTER TABLE `sale_returns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `invoice_no` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `customer_id` bigint unsigned DEFAULT NULL,
  `shift_id` bigint unsigned DEFAULT NULL,
  `subtotal` decimal(12,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `tax` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total` decimal(12,2) NOT NULL DEFAULT '0.00',
  `paid_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `change_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'completed',
  `note` text COLLATE utf8mb4_unicode_ci,
  `sold_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sales_invoice_no_unique` (`invoice_no`),
  KEY `sales_user_id_foreign` (`user_id`),
  KEY `sales_customer_id_foreign` (`customer_id`),
  KEY `sales_shift_id_foreign` (`shift_id`),
  KEY `sales_status_index` (`status`),
  KEY `sales_sold_at_index` (`sold_at`),
  CONSTRAINT `sales_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_shift_id_foreign` FOREIGN KEY (`shift_id`) REFERENCES `shifts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (4,'INV-20261030-000004',1,1,3,10.00,7.00,22.91,25.91,70.00,44.09,'voided','Customer purchased products\n[VOID] Cashier entered the wrong product quantity','2026-10-30 13:46:22','2026-10-30 13:46:22','2026-10-30 13:53:39'),(5,'INV-20261031-000005',1,1,4,10.00,7.00,22.91,25.91,70.00,44.09,'partially_refunded','Customer purchased products','2026-10-31 04:54:57','2026-10-31 04:54:57','2026-11-01 13:39:25'),(6,'INV-20261031-000006',1,1,4,0.03,0.00,0.00,0.03,0.03,0.00,'completed','Customer KHQR payment','2026-10-31 13:08:56','2026-10-31 13:08:56','2026-10-31 13:08:56');
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'store_name','Brewly Coffee Shop','2026-11-02 14:17:42','2026-11-02 14:17:42'),(2,'store_phone','012345678','2026-11-02 14:17:42','2026-11-02 14:17:42'),(3,'store_address','Phnom Penh, Cambodia','2026-11-02 14:17:42','2026-11-02 14:17:42'),(4,'store_email','admin@brewly.com','2026-11-02 14:17:42','2026-11-02 14:17:42'),(5,'receipt_footer','Thank you for shopping!','2026-11-02 14:17:42','2026-11-02 14:21:39'),(6,'tax_id','TAX-001','2026-11-02 14:21:39','2026-11-02 14:21:39'),(7,'receipt_header','Welcome to Brewly','2026-11-02 14:21:39','2026-11-02 14:21:39');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shifts`
--

DROP TABLE IF EXISTS `shifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shifts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `opening_cash` decimal(12,2) NOT NULL DEFAULT '0.00',
  `closing_cash` decimal(12,2) DEFAULT NULL,
  `expected_cash` decimal(12,2) DEFAULT NULL,
  `difference` decimal(12,2) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `note` text COLLATE utf8mb4_unicode_ci,
  `opened_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `closed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shifts_user_id_status_index` (`user_id`,`status`),
  CONSTRAINT `shifts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shifts`
--

LOCK TABLES `shifts` WRITE;
/*!40000 ALTER TABLE `shifts` DISABLE KEYS */;
INSERT INTO `shifts` VALUES (1,1,100.00,550.00,100.00,450.00,'closed','Morning shift opening\nClose: End of evening shift','2026-10-30 13:18:44','2026-10-30 13:19:56','2026-10-30 13:18:44','2026-10-30 13:19:56'),(2,1,150.00,550.00,150.00,400.00,'closed','Morning shift opening\nClose: End of evening shift','2026-10-30 13:21:11','2026-10-30 13:21:25','2026-10-30 13:21:11','2026-10-30 13:21:25'),(3,1,150.00,550.00,150.00,400.00,'closed','Morning shift opening\nClose: End of evening shift','2026-10-30 13:31:38','2026-10-30 13:55:27','2026-10-30 13:31:38','2026-10-30 13:55:27'),(4,1,150.00,NULL,NULL,NULL,'open','Morning shift opening','2026-10-31 04:47:46',NULL,'2026-10-31 04:47:46','2026-10-31 04:47:46');
/*!40000 ALTER TABLE `shifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_movements`
--

DROP TABLE IF EXISTS `stock_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_movements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qty_change` decimal(12,3) NOT NULL,
  `qty_before` decimal(12,3) NOT NULL,
  `qty_after` decimal(12,3) NOT NULL,
  `reference_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_id` bigint unsigned DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stock_movements_user_id_foreign` (`user_id`),
  KEY `stock_movements_reference_type_reference_id_index` (`reference_type`,`reference_id`),
  KEY `stock_movements_product_id_created_at_index` (`product_id`,`created_at`),
  KEY `stock_movements_type_index` (`type`),
  CONSTRAINT `stock_movements_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `stock_movements_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_movements`
--

LOCK TABLES `stock_movements` WRITE;
/*!40000 ALTER TABLE `stock_movements` DISABLE KEYS */;
INSERT INTO `stock_movements` VALUES (1,1,1,'initial',100.000,0.000,100.000,NULL,NULL,'Opening stock','2026-10-28 12:28:06','2026-10-28 12:28:06'),(2,1,1,'adjustment',10.000,100.000,110.000,NULL,NULL,'Physical stock correction','2026-10-29 14:04:37','2026-10-29 14:04:37'),(3,1,1,'adjustment',-3.000,110.000,107.000,NULL,NULL,'Three units missing during stock count','2026-10-29 14:09:03','2026-10-29 14:09:03'),(4,1,1,'damage',-2.000,107.000,105.000,NULL,NULL,'Two units damaged during storage','2026-10-29 14:10:05','2026-10-29 14:10:05'),(5,1,1,'adjustment',-63.000,105.000,42.000,NULL,NULL,'Physical inventory count','2026-10-29 14:10:36','2026-10-29 14:10:36'),(6,1,1,'purchase',10.000,42.000,52.000,'App\\Models\\Purchases',1,'Purchase PO-TEST-0004','2026-10-29 14:20:24','2026-10-29 14:20:24'),(7,1,1,'purchase',10.000,52.000,62.000,'App\\Models\\Purchases',2,'Purchase PO-TEST-0006','2026-10-29 14:23:10','2026-10-29 14:23:10'),(8,1,1,'purchase',10.000,62.000,72.000,'App\\Models\\Purchases',3,'Purchase PO-TEST-0007','2026-10-29 14:32:11','2026-10-29 14:32:11'),(9,1,1,'sale',-2.000,72.000,70.000,'App\\Models\\Sales',4,'Sale INV-20261030-000004','2026-10-30 13:46:22','2026-10-30 13:46:22'),(10,2,1,'sale',-3.000,93.100,90.100,'App\\Models\\Sales',4,'Sale INV-20261030-000004','2026-10-30 13:46:22','2026-10-30 13:46:22'),(11,1,1,'return',2.000,70.000,72.000,'App\\Models\\Sales',4,'Void INV-20261030-000004','2026-10-30 13:53:39','2026-10-30 13:53:39'),(12,2,1,'return',3.000,90.100,93.100,'App\\Models\\Sales',4,'Void INV-20261030-000004','2026-10-30 13:53:39','2026-10-30 13:53:39'),(13,1,1,'sale',-2.000,72.000,70.000,'App\\Models\\Sales',5,'Sale INV-20261031-000005','2026-10-31 04:54:57','2026-10-31 04:54:57'),(14,2,1,'sale',-3.000,93.100,90.100,'App\\Models\\Sales',5,'Sale INV-20261031-000005','2026-10-31 04:54:57','2026-10-31 04:54:57'),(15,2,1,'sale',-2.000,90.100,88.100,'App\\Models\\Sales',6,'Sale INV-20261031-000006','2026-10-31 13:08:56','2026-10-31 13:08:56'),(16,3,1,'sale',-1.000,680.348,679.348,'App\\Models\\Sales',6,'Sale INV-20261031-000006','2026-10-31 13:08:56','2026-10-31 13:08:56');
/*!40000 ALTER TABLE `stock_movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `suppliers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_person` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `note` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `suppliers_name_index` (`name`),
  KEY `suppliers_phone_index` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES (1,'ABC Coffee Supplier Updated','Dara Sok','012345678','dara@example.com','Phnom Penh, Cambodia','Updated supplier information',121,'2008-10-25 18:26:02','2026-10-29 07:18:36',NULL),(2,'Aoki Airi','5tWfBquE43','21-3401-6405','airi10@icloud.com','Navicat Data Modeler is a powerful and cost-effective database design tool which helps you build high-quality conceptual, logical and physical data models. The reason why a great man is great is that he resolves to be a great man. To successfully establish a new connection to local/remote server - no matter via SSL or SSH, set the database login information in the General tab. Instead of wondering when your next vacation is, maybe you should set up a life you don’t need to escape from. It can also manage cloud databases such as Amazon Redshift, Amazon RDS, Alibaba Cloud. Features in Navicat are sophisticated enough to provide professional developers for all their specific needs, yet easy to learn for users who are new to database server. A query is used to extract data from the database in a readable format according to the user\'s request. The reason why a great man is great is that he resolves to be a great man. If your Internet Service Provider (ISP) does not provide direct access to its server, Secure Tunneling Protocol (SSH) / HTTP is another solution. A man is not old until regrets take the place of dreams. Navicat Monitor requires a repository to store alerts and metrics for historical analysis. A comfort zone is a beautiful place, but nothing ever grows there. All the Navicat Cloud objects are located under different projects. You can share the project to other Navicat Cloud accounts for collaboration. Navicat Monitor requires a repository to store alerts and metrics for historical analysis. Genius is an infinite capacity for taking pains. The past has no power over the present moment. Difficult circumstances serve as a textbook of life for people. There is no way to happiness. Happiness is the way. I will greet this day with love in my heart. To successfully establish a new connection to local/remote server - no matter via SSL or SSH, set the database login information in the General tab. Navicat provides a wide range advanced features, such as compelling code editing capabilities, smart code-completion, SQL formatting, and more. The reason why a great man is great is that he resolves to be a great man. Navicat provides a wide range advanced features, such as compelling code editing capabilities, smart code-completion, SQL formatting, and more. Such sessions are also susceptible to session hijacking, where a malicious user takes over your session once you have authenticated. Navicat authorizes you to make connection to remote servers running on different platforms (i.e. Windows, macOS, Linux and UNIX), and supports PAM and GSSAPI authentication. To get a secure connection, the first thing you need to do is to install OpenSSL Library and download Database Source. To clear or reload various internal caches, flush tables, or acquire locks, control-click your connection in the Navigation pane and select Flush and choose the flush option. You must have the reload privilege to use this feature. Monitored servers include MySQL, MariaDB and SQL Server, and compatible with cloud databases like Amazon RDS, Amazon Aurora, Oracle Cloud, Google Cloud and Microsoft Azure. It is used while your ISPs do not allow direct connections, but allows establishing HTTP connections. A comfort zone is a beautiful place, but nothing ever grows there. The reason why a great man is great is that he resolves to be a great man. Optimism is the one quality more associated with success and happiness than any other. Navicat Data Modeler is a powerful and cost-effective database design tool which helps you build high-quality conceptual, logical and physical data models. I destroy my enemies when I make them my friends. I destroy my enemies when I make them my friends. To clear or reload various internal caches, flush tables, or acquire locks, control-click your connection in the Navigation pane and select Flush and choose the flush option. You must have the reload privilege to use this feature. It is used while your ISPs do not allow direct connections, but allows establishing HTTP connections. Navicat Monitor requires a repository to store alerts and metrics for historical analysis. With its well-designed Graphical User Interface(GUI), Navicat lets you quickly and easily create, organize, access and share information in a secure and easy way. To successfully establish a new connection to local/remote server - no matter via SSL, SSH or HTTP, set the database login information in the General tab. Monitored servers include MySQL, MariaDB and SQL Server, and compatible with cloud databases like Amazon RDS, Amazon Aurora, Oracle Cloud, Google Cloud and Microsoft Azure. Navicat Data Modeler is a powerful and cost-effective database design tool which helps you build high-quality conceptual, logical and physical data models. It is used while your ISPs do not allow direct connections, but allows establishing HTTP connections. HTTP Tunneling is a method for connecting to a server that uses the same protocol (http://) and the same port (port 80) as a web server does. All the Navicat Cloud objects are located under different projects. You can share the project to other Navicat Cloud accounts for collaboration. Navicat Monitor can be installed on any local computer or virtual machine and does not require any software installation on the servers being monitored. The reason why a great man is great is that he resolves to be a great man. Always keep your eyes open. Keep watching. Because whatever you see can inspire you. The first step is as good as half over. SSH serves to prevent such vulnerabilities and allows you to access a remote server\'s shell without compromising security. I will greet this day with love in my heart. Actually it is just in an idea when feel oneself can achieve and cannot achieve. If it scares you, it might be a good thing to try. In the Objects tab, you can use the List List, Detail Detail and ER Diagram ER Diagram buttons to change the object view. How we spend our days is, of course, how we spend our lives. Remember that failure is an event, not a person. Anyone who has never made a mistake has never tried anything new. It collects process metrics such as CPU load, RAM usage, and a variety of other resources over SSH/SNMP. The reason why a great man is great is that he resolves to be a great man. It provides strong authentication and secure encrypted communications between two hosts, known as SSH Port Forwarding (Tunneling), over an insecure network. The past has no power over the present moment. The past has no power over the present moment. The first step is as good as half over. You can select any connections, objects or projects, and then select the corresponding buttons on the Information Pane. Difficult circumstances serve as a textbook of life for people. Success consists of going from failure to failure without loss of enthusiasm. A query is used to extract data from the database in a readable format according to the user\'s request. What you get by achieving your goals is not as important as what you become by achieving your goals. The reason why a great man is great is that he resolves to be a great man. You must be the change you wish to see in the world. Navicat provides powerful tools for working with queries: Query Editor for editing the query text directly, and Query Builder, Find Builder or Aggregate Builder for building queries visually. What you get by achieving your goals is not as important as what you become by achieving your goals. Navicat provides powerful tools for working with queries: Query Editor for editing the query text directly, and Query Builder, Find Builder or Aggregate Builder for building queries visually. Sometimes you win, sometimes you learn. Such sessions are also susceptible to session hijacking, where a malicious user takes over your session once you have authenticated. It wasn’t raining when Noah built the ark. You must be the change you wish to see in the world. It provides strong authentication and secure encrypted communications between two hosts, known as SSH Port Forwarding (Tunneling), over an insecure network. Instead of wondering when your next vacation is, maybe you should set up a life you don’t need to escape from. It provides strong authentication and secure encrypted communications between two hosts, known as SSH Port Forwarding (Tunneling), over an insecure network. Actually it is just in an idea when feel oneself can achieve and cannot achieve. Import Wizard allows you to import data to tables/collections from CSV, TXT, XML, DBF and more. To get a secure connection, the first thing you need to do is to install OpenSSL Library and download Database Source. Navicat Cloud provides a cloud service for synchronizing connections, queries, model files and virtual group information from Navicat, other Navicat family members, different machines and different platforms.','To clear or reload various internal caches, flush tables, or acquire locks, control-click your connection in the Navigation pane and select Flush and choose the flush option. You must have the reload privilege to use this feature. Typically, it is employed as an encrypted version of Telnet. Remember that failure is an event, not a person. You must be the change you wish to see in the world. Navicat Data Modeler is a powerful and cost-effective database design tool which helps you build high-quality conceptual, logical and physical data models. It is used while your ISPs do not allow direct connections, but allows establishing HTTP connections. It wasn’t raining when Noah built the ark. The Information Pane shows the detailed object information, project activities, the DDL of database objects, object dependencies, membership of users/roles and preview. Anyone who has ever made anything of importance was disciplined. Navicat Monitor requires a repository to store alerts and metrics for historical analysis. All the Navicat Cloud objects are located under different projects. You can share the project to other Navicat Cloud accounts for collaboration. Navicat Cloud provides a cloud service for synchronizing connections, queries, model files and virtual group information from Navicat, other Navicat family members, different machines and different platforms. You cannot save people, you can just love them. Navicat allows you to transfer data from one database and/or schema to another with detailed analytical process. The reason why a great man is great is that he resolves to be a great man. A man is not old until regrets take the place of dreams. You cannot save people, you can just love them. Actually it is just in an idea when feel oneself can achieve and cannot achieve. Anyone who has ever made anything of importance was disciplined. The On Startup feature allows you to control what tabs appear when you launch Navicat. Remember that failure is an event, not a person. Navicat Cloud provides a cloud service for synchronizing connections, queries, model files and virtual group information from Navicat, other Navicat family members, different machines and different platforms. If opportunity doesn’t knock, build a door. The repository database can be an existing MySQL, MariaDB, PostgreSQL, SQL Server, or Amazon RDS instance. Instead of wondering when your next vacation is, maybe you should set up a life you don’t need to escape from. Import Wizard allows you to import data to tables/collections from CSV, TXT, XML, DBF and more. The Synchronize to Database function will give you a full picture of all database differences. If it scares you, it might be a good thing to try. To successfully establish a new connection to local/remote server - no matter via SSL or SSH, set the database login information in the General tab. Typically, it is employed as an encrypted version of Telnet. Navicat is a multi-connections Database Administration tool allowing you to connect to MySQL, Oracle, PostgreSQL, SQLite, SQL Server, MariaDB and/or MongoDB databases, making database administration to multiple kinds of database so easy. Monitored servers include MySQL, MariaDB and SQL Server, and compatible with cloud databases like Amazon RDS, Amazon Aurora, Oracle Cloud, Google Cloud and Microsoft Azure. Navicat Cloud could not connect and access your databases. By which it means, it could only store your connection settings, queries, model files, and virtual group; your database passwords and data (e.g. tables, views, etc) will not be stored to Navicat Cloud. The Information Pane shows the detailed object information, project activities, the DDL of database objects, object dependencies, membership of users/roles and preview. Typically, it is employed as an encrypted version of Telnet. It is used while your ISPs do not allow direct connections, but allows establishing HTTP connections. Creativity is intelligence having fun. Creativity is intelligence having fun. All journeys have secret destinations of which the traveler is unaware. It provides strong authentication and secure encrypted communications between two hosts, known as SSH Port Forwarding (Tunneling), over an insecure network. I will greet this day with love in my heart. Anyone who has never made a mistake has never tried anything new. Instead of wondering when your next vacation is, maybe you should set up a life you don’t need to escape from. Sometimes you win, sometimes you learn. A man is not old until regrets take the place of dreams. Sometimes you win, sometimes you learn. Navicat Data Modeler enables you to build high-quality conceptual, logical and physical data models for a wide variety of audiences. Secure SHell (SSH) is a program to log in into another computer over a network, execute commands on a remote server, and move files from one machine to another. You will succeed because most people are lazy. Navicat Cloud provides a cloud service for synchronizing connections, queries, model files and virtual group information from Navicat, other Navicat family members, different machines and different platforms. In other words, Navicat provides the ability for data in different databases and/or schemas to be kept up-to-date so that each repository contains the same information. Remember that failure is an event, not a person. The Synchronize to Database function will give you a full picture of all database differences. To get a secure connection, the first thing you need to do is to install OpenSSL Library and download Database Source. Anyone who has never made a mistake has never tried anything new. Navicat Monitor requires a repository to store alerts and metrics for historical analysis. Such sessions are also susceptible to session hijacking, where a malicious user takes over your session once you have authenticated. Export Wizard allows you to export data from tables, collections, views, or query results to any available formats. A comfort zone is a beautiful place, but nothing ever grows there. To get a secure connection, the first thing you need to do is to install OpenSSL Library and download Database Source.',16,'2015-09-07 01:46:35','2000-02-14 02:09:47',NULL),(3,'ABC Coffee Supplier','Dara Sok','012345678','dara@example.com','Phnom Penh, Cambodia','Main coffee bean supplier',1,'2026-10-29 07:12:32','2026-10-29 07:23:30',NULL);
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employee_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_employee_code_unique` (`employee_code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,'Administrator','admin@example.com',NULL,NULL,NULL,'$2y$12$xBZm7l8gru3yeV4zrEQGd.b9HiiYQ8i8e.jAm2E/qAohNgmIQR7tC',NULL,1,NULL,'2026-10-28 07:40:44','2026-10-28 07:40:44',NULL),(2,NULL,'Admin','admin@pos.test',NULL,NULL,NULL,'$2y$12$QyxXPWOwwT2Q60Bd3ciV1OSysn9KhPz3SCtdENCH.xP3BV77mA8AG',NULL,1,NULL,'2026-10-28 07:44:49','2026-10-28 07:44:49',NULL),(3,NULL,'Test User','test@example.com',NULL,'users/Q9groXPbo8cppXI9bdU2QVQGPdu23Rhre2TYFm5h.jpg','2026-10-28 07:50:31','$2y$12$1JlxE0aSCQSxVuJDX6aTzuFZj1I0/UzWP3vUA9EwlJQDK2LdVXNGS',NULL,1,'QiEimvIAkG','2026-10-28 07:50:31','2026-10-28 12:47:31',NULL),(4,'EMP001','Sok Dara','thida@gmail.com','037272358','0',NULL,'$2y$12$OBFz0lkHDqqqpa9ClwAxney6EdtEr9ccpUxwd/LDgiPOAeIk0pTJ2','$2y$12$k7HAHJe2BPpY6/BKAifsAuEf2iCNKi6R5mcH4M2VOCr6wCNus0JNy',1,NULL,'2026-10-28 12:33:33','2026-10-28 12:33:33',NULL),(5,'EMP004','Sok Dara','thida1@gmail.com','037272358','0',NULL,'$2y$12$4Fx9yq2uUQEObHw4QxhmK.5F9kuMjJsxP/wqCLFxLMFK6DbL2wut2','$2y$12$wb/b7REX2dd0ohDPsujZS.vmvuGgDu4mLBMHZoet9RP13aesc6cuC',1,NULL,'2026-10-28 12:41:24','2026-10-28 12:41:24',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'retail_pos'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-04 12:32:14
